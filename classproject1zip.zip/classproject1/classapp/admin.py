from django.contrib import admin
from classapp.models import Person
# Register your models here.

admin.site.register(Person)