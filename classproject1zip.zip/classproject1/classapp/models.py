from django.db import models
from django.utils import timezone

# Create your models here.
class Person(models.Model):
    FirstName = models.CharField(max_length = 200)
    LastName = models.CharField(max_length=200)
    Email = models.EmailField(max_length = 200)
    DateOfBirth = models.DateField(null=True)

    def __str__ (self):
        template = '{0,FirstName}, {0,LastName}, {0,Email}, {0, DateOfBirth}'
        return template.format(self)