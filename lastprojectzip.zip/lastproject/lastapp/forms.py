from django import forms

class BasicForm(forms.Form):
    FirstName = forms.CharField()
    LastName = forms.CharField()
    Email = forms.EmailField()
    Date_of_Birth = forms.DateField()