from django.shortcuts import render
from lastapp import forms
from django.http import HttpResponse
# Create your views here.
def index(request):
    form_object = forms.BasicForm

    if request.method == "POST":
        form_object = forms.BasicForm(request.POST)
        if form_object.is_valid():
            print(form_object.cleaned_data["FirstName"])
            print(form_object.cleaned_data["LastName"])
            print(form_object.cleaned_data["Email"])
            print(form_object.cleaned_data["Date_of_Birth"])

    return HttpResponse("<h1> This is an H1 heading</h1>")



    # return render(request, 'index.html', {'form_object' :form_object})