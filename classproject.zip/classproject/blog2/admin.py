from django.contrib import admin
from blog2.models import *
# Register your models here.

admin.site.register(Car)
admin.site.register(Student)
admin.site.register(Program)
admin.site.register(Department)