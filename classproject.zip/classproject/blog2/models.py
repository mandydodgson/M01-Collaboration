from django.db import models

# Create your models here.
class Car(models.Model):
    car_make = models.CharField(max_length = 200)
    car_model = models.CharField(max_length = 200)
    car_year = models.CharField(max_length = 10)

    def __str__(self):
        modify = '{0.car_make} {0.car_model} {0.car_year}'
        return modify.format(self)
    
class Department(models.Model):
        department_id = models.CharField(max_length = 10, unique = True)
        department_name = models.CharField(max_length = 200)
        building = models.CharField(max_length = 200)

        def __str__(self):
            modify = '{0.department_id} {0.department_name} {0.building}'
            return modify.format(self)


class Program(models.Model):
        program_id = models.CharField(max_length = 10, unique = True)
        program_name = models.CharField(max_length = 200)
        department_id = models.ForeignKey(Department, on_delete = models.CASCADE)

        def __str__(self):
            modify = '{0.program_id} {0.program_name} {0.department_id}'
            return modify.format(self)


class Student(models.Model):
        student_id = models.CharField(max_length = 10, unique = True)
        student_fname = models.CharField(max_length = 200)
        student_lname = models.CharField(max_length = 10)
        student_email = models.EmailField(blank = True)
        


        def __str__(self):
            modify = '{0.student_id} {0.student_fname} {0.student_lname} {0.student_email}'
            return modify.format(self)
    

    
    
    