from django.shortcuts import render
from django.http import HttpResponse
from blog2.models import Student, Program, Department
def index(request):
    student_list = Student.objects. order_by ("student_id")
    mydictionary = {'new_key': "Welcome to Ivy Tech Community College", 'students': student_list}
    return render(request, 'signin.html', context = mydictionary)
   

